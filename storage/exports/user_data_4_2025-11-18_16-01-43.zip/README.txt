Your Personal Data Export
========================

This archive contains all your personal data stored in Bishwo Calculator.

Files Included:
- user_data.json: Complete data in JSON format
- profile.csv: Your profile information
- calculations.csv: Your calculation history
- activity_log.csv: Your activity logs
- README.txt: This file

Data Protection Rights:
Under GDPR and data protection regulations, you have the right to:
- Access your personal data
- Rectify inaccurate data
- Erase your data (right to be forgotten)
- Restrict processing of your data
- Data portability
- Object to processing

For more information or to exercise your rights, please contact us.

Export Date: 2025-11-18 16:01:43
